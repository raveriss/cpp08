/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raveriss <raveriss@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 15:29:47 by raveriss          #+#    #+#             */
/*   Updated: 2024/06/13 15:30:12 by raveriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../incs/MutantStack.hpp"
#include <iostream>
#include <cassert>

void runTests() {
    // Test de l'itérateur sur une pile vide
    MutantStack<int> emptyStack;
    assert(emptyStack.begin() == emptyStack.end());

    // Test de la taille après plusieurs opérations
    MutantStack<int> sizeTestStack;
    sizeTestStack.push(1);
    sizeTestStack.push(2);
    sizeTestStack.push(3);
    assert(sizeTestStack.size() == 3);
    sizeTestStack.pop();
    assert(sizeTestStack.size() == 2);

    // Test de la copie et de l'affectation
    MutantStack<int> originalStack;
    originalStack.push(42);
    MutantStack<int> copyStack(originalStack);
    assert(copyStack.top() == 42);
    MutantStack<int> assignStack;
    assignStack = originalStack;
    assert(assignStack.top() == 42);

    // Test de la validité des itérateurs après des modifications
    MutantStack<int> iterStack;
    iterStack.push(10);
    iterStack.push(20);
    MutantStack<int>::iterator it = iterStack.begin();
    assert(*it == 10);
    iterStack.push(30);
    ++it;
    assert(*it == 20);
}

int main() {
    MutantStack<int> mstack;

    mstack.push(5);
    mstack.push(17);

    std::cout << mstack.top() << std::endl; // Devrait afficher 17

    mstack.pop();

    std::cout << mstack.size() << std::endl; // Devrait afficher 1

    mstack.push(3);
    mstack.push(5);
    mstack.push(737);
    //[...]
    mstack.push(0);

    MutantStack<int>::iterator it = mstack.begin();
    MutantStack<int>::iterator ite = mstack.end();

    ++it;
    --it;
    while (it != ite) {
        std::cout << *it << std::endl;
        ++it;
    }

    std::stack<int> s(mstack);

    // Exécuter les tests unitaires
    runTests();

    return 0;
}
